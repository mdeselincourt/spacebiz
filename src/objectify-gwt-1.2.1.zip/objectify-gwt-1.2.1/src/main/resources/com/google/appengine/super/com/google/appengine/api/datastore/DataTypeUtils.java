package com.google.appengine.api.datastore;

/**
 * GWT emulation class.
 */
public class DataTypeUtils
{
	public static final int MAX_STRING_PROPERTY_LENGTH = 500;
	public static final int MAX_SHORT_BLOB_PROPERTY_LENGTH = 500;
	public static final int MAX_LINK_PROPERTY_LENGTH = 2038;
}
